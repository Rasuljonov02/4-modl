# ---------- 21.08.23 ----------(45)(Examine-4)

## Questions

    ✅ Find Max
    ✅ Find
    ✅ Search
    ✅ Sum
